#!/usr/bin/env perl
#
print "Location: http://www.example.org/\r\n\n\n";
exit;
